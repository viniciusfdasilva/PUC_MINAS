/**
	@author Vinicius F. da Silva
*/
final class ClassToken{
    public static final String PALAVRA_RESERVADA = "PALAVRA RESERVADA";
	public static final String IDENTIFICADOR = "IDENTIFICADOR";
	public static final String CARACTER_ESPECIAL = "CARACTER ESPECIAL";
	public static final String NUMERO_INTEIRO = "NUMERO INTEIRO";
	public static final String OUTROS_CARACTERES = "OUTROS CARACTERES";
	public static final String STRING = "STRING";
}// End ClassToken