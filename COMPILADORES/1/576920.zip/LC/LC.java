import java.io.File;
import java.io.FileNotFoundException;
import java.lang.ArrayIndexOutOfBoundsException;

/**
	@author Vinicius F. da Silva
*/
public class LC{
    static SymbolTable symbolTable;
    public static void main(String[] args){
        try{  
            System.out.println(args[0]);
            LexicalAnalyzer lexical = new LexicalAnalyzer(new File(args[0]));
            AnaliseSintatica sintatica = new AnaliseSintatica(lexical);
            Symbol s = lexical.analiseLexica();
            sintatica.setToken(s.getLexema());
            sintatica.procedureS();
        }catch(FileNotFoundException | ArrayIndexOutOfBoundsException e){
            System.out.println("Arquivo não encontrado ou arquivo fonte não informado!");
        }// End catch
    }// End main()
}// End LC